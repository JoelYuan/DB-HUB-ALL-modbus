package main

import (
	"log"
	"time"

	"DB-HUB-ALL-modbus/internal/cache"
	"DB-HUB-ALL-modbus/internal/config"
	"DB-HUB-ALL-modbus/internal/devices"
	"DB-HUB-ALL-modbus/internal/storage"
	"DB-HUB-ALL-modbus/internal/web"
)

func main() {

	// ======================================================
	// 1. 加载配置文件
	// ======================================================
	err := config.Load("config.yaml")
	if err != nil {
		log.Fatal("加载配置失败:", err)
	}
	// log.Println("配置加载完成")

	// ======================================================
	// 2. 初始化数据库
	// ======================================================
	storage.Init(config.C.Global.DBPath)
	// log.Println("数据库初始化完成")

	// ======================================================
	// 3. 初始化设备管理器（RTU/TCP Client Pool）
	// ======================================================
	err = devices.InitAll()
	if err != nil {
		log.Fatal("初始化设备管理器失败:", err)
	}
	// log.Println("设备管理器初始化完成")

	// ======================================================
	// 4. 启动所有设备的轮询器
	// ======================================================
	devices.StartAll()
	// log.Println("RTU/TCP 轮询器已全部启动")

	// ======================================================
	// 5. 启动数据保存定时器
	// ======================================================
	go func() {
		ticker := time.NewTicker(1 * time.Second) // 每秒保存一次数据
		defer ticker.Stop()

		// 初始化快照
		cache.Global.Snapshot()

		for {
			<-ticker.C
			// 先保存差异数据，然后创建快照
			storage.SaveDiff()
			cache.Global.Snapshot()
		}
	}()

	// ======================================================
	// 6. 启动 Web Server（在线状态 + Tag 查询）
	// ======================================================
	go web.Start(config.C.Global.WebPort)

	// ======================================================
	// 主线程阻塞
	// ======================================================
	select {}
}
