#!/usr/bin/env python3
"""
直接检查SQLite数据库中的数据存储情况
"""

import sqlite3
import sys
from datetime import datetime

def check_database():
    """直接检查SQLite数据库内容"""
    try:
        # 连接到SQLite数据库
        conn = sqlite3.connect('data.db')
        cursor = conn.cursor()
        
        print("=== 检查SQLite数据库 ===")
        print(f"数据库路径: data.db")
        
        # 检查表结构
        cursor.execute("PRAGMA table_info(tag_log)")
        columns = cursor.fetchall()
        print("\n表结构:")
        for col in columns:
            print(f"  - {col[1]}: {col[2]}")
        
        # 查询记录总数
        cursor.execute("SELECT COUNT(*) FROM tag_log")
        total_records = cursor.fetchone()[0]
        print(f"\n总记录数: {total_records}")
        
        # 查询最近的记录
        cursor.execute("SELECT ts, tag, value FROM tag_log ORDER BY ts DESC LIMIT 20")
        recent_records = cursor.fetchall()
        
        if recent_records:
            print("\n最近20条记录:")
            print("-" * 60)
            print(f"{'时间':<20} {'变量':<12} {'值':<15}")
            print("-" * 60)
            
            for record in recent_records:
                timestamp = record[0]
                variable = record[1]
                value = record[2]
                print(f"{timestamp:<20} {variable:<12} {value:<15}")
        else:
            print("\n数据库中没有记录")
        
        # 查询每个变量的记录数
        cursor.execute("SELECT tag, COUNT(*) FROM tag_log GROUP BY tag")
        var_counts = cursor.fetchall()
        
        if var_counts:
            print("\n各变量记录数:")
            for var, count in var_counts:
                print(f"  - {var}: {count} 条")
        
        # 关闭连接
        conn.close()
        
    except sqlite3.Error as e:
        print(f"SQLite错误: {e}")
        return False
    except Exception as e:
        print(f"其他错误: {e}")
        return False
    
    return True

def export_to_csv():
    """导出所有数据到CSV文件"""
    try:
        conn = sqlite3.connect('data.db')
        cursor = conn.cursor()
        
        cursor.execute("SELECT ts, tag, value FROM tag_log ORDER BY ts ASC")
        all_records = cursor.fetchall()
        
        if all_records:
            filename = f"db_export_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
            with open(filename, 'w', newline='', encoding='utf-8') as csvfile:
                csvfile.write("ts,tag,value\n")
                for record in all_records:
                    csvfile.write(f"{record[0]},{record[1]},{record[2]}\n")
            print(f"\n数据已导出到: {filename}")
        
        conn.close()
        return True
    
    except Exception as e:
        print(f"导出错误: {e}")
        return False

if __name__ == "__main__":
    print("S7 PLC 数据库检查工具")
    print("=" * 50)
    
    success = check_database()
    
    if success:
        export = input("\n是否导出所有数据到CSV文件? (y/n): ")
        if export.lower() == 'y':
            export_to_csv()
    
    print("\n检查完成")
