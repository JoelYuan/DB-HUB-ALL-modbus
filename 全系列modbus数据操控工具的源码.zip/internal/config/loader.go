package config

import (
	"DB-HUB-ALL-modbus/internal/types"
	"os"

	"gopkg.in/yaml.v3"
)

type Config struct {
	Global  types.GlobalConfig   `yaml:"global"`
	Devices []types.DeviceConfig `yaml:"devices"`
}

var C Config

func Load(path string) error {
	b, err := os.ReadFile(path)
	if err != nil {
		return err
	}
	return yaml.Unmarshal(b, &C)
}
