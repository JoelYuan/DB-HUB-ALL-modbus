package poller

import (
	"fmt"
	"log"
	"time"

	"github.com/goburrow/modbus"

	"DB-HUB-ALL-modbus/internal/config"
	"DB-HUB-ALL-modbus/internal/types"
)

type TCPClient struct {
	cfg     types.DeviceConfig
	handler *modbus.TCPClientHandler
	client  modbus.Client
	// reconnect/backoff
	backoff time.Duration
}

// NewTCPClient 建立并返回 TCP 客户端，如果连接失败则返回仍可用的客户端，读/写会尝试重连
func NewTCPClient(cfg types.DeviceConfig) (ModbusClient, error) {
	c := &TCPClient{
		cfg:     cfg,
		handler: nil,
		client:  nil,
		backoff: 1 * time.Second,
	}

	// try connect initially
	if err := c.connect(); err != nil {
		// log but don't fatal — manager will handle retries
		log.Printf("[TCP %s] initial connect failed: %v — will retry on operations", cfg.Name, err)
	}
	return c, nil
}

func (c *TCPClient) connect() error {
	addr := c.cfg.Address
	handler := modbus.NewTCPClientHandler(addr)
	handler.Timeout = 500 * time.Millisecond // Default 500ms timeout
	if c.cfg.UnitID != 0 {
		handler.SlaveId = byte(c.cfg.UnitID)
	}
	if err := handler.Connect(); err != nil {
		return err
	}
	c.handler = handler
	c.client = modbus.NewClient(handler)
	// reset backoff
	c.backoff = 1 * time.Second
	return nil
}

func (c *TCPClient) Close() error {
	if c.handler != nil {
		return c.handler.Close()
	}
	return nil
}

func (c *TCPClient) Read(fc uint8, addr uint16, qty uint16) ([]uint16, error) {
	retries := config.C.Global.RetryTimes
	var lastErr error
	const fixedQty uint16 = 1 // 固定使用长度1，离散单点读取

	for attempt := 0; attempt <= retries; attempt++ {
		// ensure connected
		if c.client == nil || c.handler == nil {
			if err := c.connect(); err != nil {
				lastErr = err
				// backoff then retry
				time.Sleep(c.backoff)
				if c.backoff < 30*time.Second {
					c.backoff *= 2
				}
				continue
			}
		}

		switch fc {
		case 1:
			b, err := c.client.ReadCoils(addr, fixedQty)
			if err != nil {
				lastErr = err
				_ = c.Close()
				c.client, c.handler = nil, nil
				time.Sleep(20 * time.Millisecond)
				continue
			}
			return bytesToBits(b, int(fixedQty)), nil
		case 2:
			b, err := c.client.ReadDiscreteInputs(addr, fixedQty)
			if err != nil {
				lastErr = err
				_ = c.Close()
				c.client, c.handler = nil, nil
				time.Sleep(20 * time.Millisecond)
				continue
			}
			return bytesToBits(b, int(fixedQty)), nil
		case 3:
			b, err := c.client.ReadHoldingRegisters(addr, fixedQty)
			if err != nil {
				lastErr = err
				_ = c.Close()
				c.client, c.handler = nil, nil
				time.Sleep(20 * time.Millisecond)
				continue
			}
			return bytesToU16(b, int(fixedQty)), nil
		case 4:
			b, err := c.client.ReadInputRegisters(addr, fixedQty)
			if err != nil {
				lastErr = err
				_ = c.Close()
				c.client, c.handler = nil, nil
				time.Sleep(20 * time.Millisecond)
				continue
			}
			return bytesToU16(b, int(fixedQty)), nil
		default:
			return nil, fmt.Errorf("unsupported fc %d", fc)
		}
	}

	return nil, fmt.Errorf("tcp read failed addr=%d fc=%d: %v", addr, fc, lastErr)
}

func (c *TCPClient) Write(fc uint8, addr uint16, value interface{}) error {
	retries := config.C.Global.RetryTimes
	var lastErr error

	for attempt := 0; attempt <= retries; attempt++ {
		// ensure connected
		if c.client == nil || c.handler == nil {
			if err := c.connect(); err != nil {
				lastErr = err
				time.Sleep(c.backoff)
				if c.backoff < 30*time.Second {
					c.backoff *= 2
				}
				continue
			}
		}

		switch fc {
		case 5:
			var coil uint16 = 0x0000
			switch v := value.(type) {
			case bool:
				if v {
					coil = 0xFF00
				}
			case int:
				if v != 0 {
					coil = 0xFF00
				}
			default:
			}
			_, err := c.client.WriteSingleCoil(addr, coil)
			if err != nil {
				lastErr = err
				_ = c.Close()
				c.client, c.handler = nil, nil
				time.Sleep(20 * time.Millisecond)
				continue
			}
			return nil
		case 6:
			var reg uint16
			switch v := value.(type) {
			case int:
				reg = uint16(v)
			case uint16:
				reg = v
			case float32:
				reg = uint16(int(v))
			default:
				reg = 0
			}
			_, err := c.client.WriteSingleRegister(addr, reg)
			if err != nil {
				lastErr = err
				_ = c.Close()
				c.client, c.handler = nil, nil
				time.Sleep(20 * time.Millisecond)
				continue
			}
			return nil
		case 16:
			arr, ok := value.([]uint16)
			if !ok {
				// try []int
				if a2, ok2 := value.([]int); ok2 {
					arr = make([]uint16, len(a2))
					for i := range a2 {
						arr[i] = uint16(a2[i])
					}
				} else {
					return fmt.Errorf("fc16 expects []uint16")
				}
			}
			bytes := u16ToBytes(arr)
			_, err := c.client.WriteMultipleRegisters(addr, uint16(len(arr)), bytes)
			if err != nil {
				lastErr = err
				_ = c.Close()
				c.client, c.handler = nil, nil
				time.Sleep(20 * time.Millisecond)
				continue
			}
			return nil
		default:
			return fmt.Errorf("unsupported write fc %d", fc)
		}
	}

	return fmt.Errorf("tcp write failed addr=%d fc=%d: %v", addr, fc, lastErr)
}
