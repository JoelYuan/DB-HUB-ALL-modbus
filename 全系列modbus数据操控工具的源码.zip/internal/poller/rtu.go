package poller

import (
	"fmt"
	"log"
	"time"

	"github.com/goburrow/modbus"

	"DB-HUB-ALL-modbus/internal/config"
	"DB-HUB-ALL-modbus/internal/types"
)

// ModbusClient 接口定义（与 devices 包兼容）
type ModbusClient interface {
	Read(fc uint8, addr uint16, qty uint16) ([]uint16, error)
	Write(fc uint8, addr uint16, value interface{}) error
	Close() error
}

// RTUClient 实现了 ModbusClient 接口
type RTUClient struct {
	cfg     types.DeviceConfig
	handler *modbus.RTUClientHandler
	client  modbus.Client
	// protect reconnect
}

// NewRTUClient 尝试打开串口并返回客户端；若失败，返回仍可用的模拟客户端（nil handler）
func NewRTUClient(cfg types.DeviceConfig) (ModbusClient, error) {
	c := &RTUClient{cfg: cfg}

	// 注：原代码中的serial.Config探针已移除，因为未被使用
	// 直接使用modbus库的连接机制来检测串口状态

	handler := modbus.NewRTUClientHandler(cfg.Port)
	handler.BaudRate = cfg.Baud
	handler.DataBits = 8
	handler.Parity = "N"
	handler.StopBits = 1
	handler.Timeout = 500 * time.Millisecond // Default 500ms timeout

	if err := handler.Connect(); err != nil {
		// don't fail hard — return client with nil handler, will operate in "sim" mode
		log.Printf("[RTU %s] open failed: %v — using simulated RTU client", cfg.Name, err)
		c.handler = nil
		c.client = nil
		return c, nil
	}

	c.handler = handler
	c.client = modbus.NewClient(handler)
	return c, nil
}

func (c *RTUClient) Close() error {
	if c.handler != nil {
		return c.handler.Close()
	}
	return nil
}

// Read implements ModbusClient.Read for FC 1/2/3/4
// returns slice of uint16 where each element is:
// - for coil/discrete: 0 or 1 per bit
// - for regs: each uint16 value
// NOTE: Always uses qty=1 for discrete single-point reading (except FC16 for write)
func (c *RTUClient) Read(fc uint8, addr uint16, qty uint16) ([]uint16, error) {
	retries := config.C.Global.RetryTimes
	var lastErr error
	const fixedQty uint16 = 1 // 固定使用长度1，离散单点读取

	// If handler nil -> simulation mode: return zeros
	if c.handler == nil {
		// simulated: return zeros
		out := make([]uint16, int(fixedQty))
		return out, nil
	}

	for attempt := 0; attempt <= retries; attempt++ {
		// update slave id dynamically if config provides SlaveID
		if c.handler != nil && c.cfg.SlaveID != 0 {
			c.handler.SlaveId = byte(c.cfg.SlaveID)
		}

		switch fc {
		case 1:
			b, err := c.client.ReadCoils(addr, fixedQty)
			if err != nil {
				lastErr = err
				time.Sleep(10 * time.Millisecond)
				continue
			}
			return bytesToBits(b, int(fixedQty)), nil
		case 2:
			b, err := c.client.ReadDiscreteInputs(addr, fixedQty)
			if err != nil {
				lastErr = err
				time.Sleep(10 * time.Millisecond)
				continue
			}
			return bytesToBits(b, int(fixedQty)), nil
		case 3:
			b, err := c.client.ReadHoldingRegisters(addr, fixedQty)
			if err != nil {
				lastErr = err
				time.Sleep(10 * time.Millisecond)
				continue
			}
			return bytesToU16(b, int(fixedQty)), nil
		case 4:
			b, err := c.client.ReadInputRegisters(addr, fixedQty)
			if err != nil {
				lastErr = err
				time.Sleep(10 * time.Millisecond)
				continue
			}
			return bytesToU16(b, int(fixedQty)), nil
		default:
			return nil, fmt.Errorf("unsupported fc %d", fc)
		}
	}
	// after retries
	return nil, fmt.Errorf("rtu read failed addr=%d fc=%d: %v", addr, fc, lastErr)
}

// Write supports FC5 (single coil), FC6 (single register), FC16 (multiple registers)
// value parameter can be:
// - bool or int/uint for FC5
// - int/uint16/uint32 for FC6
// - []uint16 for FC16
func (c *RTUClient) Write(fc uint8, addr uint16, value interface{}) error {
	retries := config.C.Global.RetryTimes
	var lastErr error

	// simulation mode: just return nil
	if c.handler == nil {
		return nil
	}

	for attempt := 0; attempt <= retries; attempt++ {
		if c.handler != nil && c.cfg.SlaveID != 0 {
			c.handler.SlaveId = byte(c.cfg.SlaveID)
		}
		switch fc {
		case 5:
			// value -> coil true/false
			var coilVal uint16 = 0x0000
			switch v := value.(type) {
			case bool:
				if v {
					coilVal = 0xFF00
				}
			case int:
				if v != 0 {
					coilVal = 0xFF00
				}
			case uint8, uint16, uint32, uint64:
				// convert numeric -> nonzero true
				if toUint64(v) != 0 {
					coilVal = 0xFF00
				}
			default:
				// unsupported: treat as false
			}
			_, err := c.client.WriteSingleCoil(addr, coilVal)
			if err != nil {
				lastErr = err
				time.Sleep(10 * time.Millisecond)
				continue
			}
			return nil
		case 6:
			// single register
			var reg uint16
			switch v := value.(type) {
			case int:
				reg = uint16(v)
			case uint16:
				reg = v
			case uint32:
				reg = uint16(v)
			case uint64:
				reg = uint16(v)
			case float32:
				reg = uint16(int(v))
			default:
				// fallback: 0
				reg = 0
			}
			_, err := c.client.WriteSingleRegister(addr, reg)
			if err != nil {
				lastErr = err
				time.Sleep(10 * time.Millisecond)
				continue
			}
			return nil
		case 16:
			// batch registers: expect []uint16
			arr, ok := value.([]uint16)
			if !ok {
				// try []int
				if arr2, ok2 := value.([]int); ok2 {
					arr = make([]uint16, len(arr2))
					for i := range arr2 {
						arr[i] = uint16(arr2[i])
					}
				} else {
					return fmt.Errorf("fc16 write expects []uint16")
				}
			}
			// convert to bytes big-endian
			bytes := u16ToBytes(arr)
			_, err := c.client.WriteMultipleRegisters(addr, uint16(len(arr)), bytes)
			if err != nil {
				lastErr = err
				time.Sleep(10 * time.Millisecond)
				continue
			}
			return nil
		default:
			return fmt.Errorf("unsupported write fc %d", fc)
		}
	}

	return fmt.Errorf("rtu write failed addr=%d fc=%d: %v", addr, fc, lastErr)
}

// ----------------- helpers -----------------

func bytesToBits(b []byte, qty int) []uint16 {
	out := make([]uint16, qty)
	for i := 0; i < qty; i++ {
		byteIdx := i / 8
		bitIdx := uint(i % 8)
		if byteIdx >= len(b) {
			out[i] = 0
			continue
		}
		if ((b[byteIdx] >> bitIdx) & 0x1) == 1 {
			out[i] = 1
		} else {
			out[i] = 0
		}
	}
	return out
}

func bytesToU16(b []byte, qty int) []uint16 {
	out := make([]uint16, qty)
	for i := 0; i < qty; i++ {
		idx := i * 2
		if idx+1 >= len(b) {
			out[i] = 0
			continue
		}
		out[i] = uint16(b[idx])<<8 | uint16(b[idx+1])
	}
	return out
}

func u16ToBytes(arr []uint16) []byte {
	out := make([]byte, len(arr)*2)
	for i := range arr {
		out[i*2] = byte(arr[i] >> 8)
		out[i*2+1] = byte(arr[i] & 0xFF)
	}
	return out
}

func toUint64(v interface{}) uint64 {
	switch x := v.(type) {
	case uint8:
		return uint64(x)
	case uint16:
		return uint64(x)
	case uint32:
		return uint64(x)
	case uint64:
		return x
	case int:
		if x < 0 {
			return 0
		}
		return uint64(x)
	default:
		return 0
	}
}
