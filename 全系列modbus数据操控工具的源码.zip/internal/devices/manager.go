package devices

import (
	"log"
	"time"

	"DB-HUB-ALL-modbus/internal/cache"
	"DB-HUB-ALL-modbus/internal/config"
	"DB-HUB-ALL-modbus/internal/poller"
	"DB-HUB-ALL-modbus/internal/types"
)

// ---------- 运行时设备结构 ----------
type Device struct {
	Cfg        types.DeviceConfig
	ReadTasks  []*types.ReadTask
	WriteQueue chan *types.WriteTask

	Client     ModbusClient // 来自 rtu.go 或 tcp.go
	Online     bool
	RetryCount int
}

// 全局设备列表
var Devices []*Device

// ---------- 初始化 ----------
func InitAll() error {
	for _, devCfg := range config.C.Devices {
		d := &Device{
			Cfg:        devCfg,
			ReadTasks:  make([]*types.ReadTask, 0),
			WriteQueue: make(chan *types.WriteTask, 100),
			Online:     false,
			RetryCount: 0,
		}

		// 初始化 ModbusClient
		client, err := NewClient(devCfg)
		if err != nil {
			// log.Printf("[Device:%s] 初始化失败: %v", devCfg.Name, err)
		}
		d.Client = client

		// 构建读任务
		for _, rt := range devCfg.ReadTasks {
			d.ReadTasks = append(d.ReadTasks, &types.ReadTask{
				FC:       rt.FC,
				Addr:     rt.Addr,
				Len:      1, // 始终使用长度1，离散单点读取
				Tag:      rt.Tag,
				Period:   time.Duration(rt.PeriodMs) * time.Millisecond,
				LastTime: time.Time{},
			})
		}

		Devices = append(Devices, d)
	}
	return nil
}

// ---------- 启动所有设备轮询 ----------
func StartAll() {
	for _, d := range Devices {
		go d.Loop()
	}
}

// ---------- 写任务提交（供外部调用） ----------
func SubmitWrite(deviceName string, tag string, value interface{}) {
	for _, d := range Devices {
		if d.Cfg.Name == deviceName {
			// 将值写入 cache，然后写任务会写入设备
			cache.Global.SetTag(tag, value)

			// 找对应写任务
			for _, wt := range d.Cfg.WriteTasks {
				if wt.Tag == tag {
					d.WriteQueue <- &types.WriteTask{
						FC:   wt.FC,
						Addr: wt.Addr,
						Tag:  wt.Tag,
					}
				}
			}
		}
	}
}

// ---------- 设备主循环 ----------
func (d *Device) Loop() {
	pollInterval := time.Duration(config.C.Global.PollIntervalMs) * time.Millisecond

	for {
		// 1. 读任务处理
		now := time.Now()
		for _, t := range d.ReadTasks {
			if now.Sub(t.LastTime) >= t.Period {
				d.runReadTask(t)
				t.LastTime = now
			}
		}

		// 2. 自动写任务触发：检查所有写任务的标签值是否需要写入设备
		d.triggerAutoWriteTasks()

		// 3. 写任务处理（FIFO）
		d.runWriteTasks()

		time.Sleep(pollInterval)
	}
}

// ---------- 自动触发写任务 ----------
func (d *Device) triggerAutoWriteTasks() {
	// 遍历设备配置的所有写任务
	for _, wt := range d.Cfg.WriteTasks {
		// 对于每个写任务，将其添加到写队列
		d.WriteQueue <- &types.WriteTask{
			FC:   wt.FC,
			Addr: wt.Addr,
			Tag:  wt.Tag,
		}
	}
}

// ---------- 执行读任务 ----------
func (d *Device) runReadTask(t *types.ReadTask) {
	if d.Client == nil {
		log.Printf("[Device:%s] 执行读任务失败: Client为nil", d.Cfg.Name)
		return
	}

	// log.Printf("[Device:%s] 执行读任务: FC=%d, Addr=%d, Tag=%s", d.Cfg.Name, t.FC, t.Addr, t.Tag)

	data, err := d.Client.Read(t.FC, t.Addr, t.Len)
	if err != nil {
		log.Printf("[Device:%s] 读操作失败 tag=%s: %v", d.Cfg.Name, t.Tag, err)
		d.markFail(err)
		return
	}

	// log.Printf("[Device:%s] 读操作成功 tag=%s: 原始数据=%v", d.Cfg.Name, t.Tag, data)

	// 根据功能码转换数据类型
	var cacheValue interface{}
	switch t.FC {
	case 1, 2: // FC1=Read Coils, FC2=Read Discrete Inputs (flags)
		// 转换为bool值
		if len(data) > 0 && data[0] != 0 {
			cacheValue = true
		} else {
			cacheValue = false
		}
		// log.Printf("[Device:%s] 转换Flag数据: tag=%s, 转换后=%v", d.Cfg.Name, t.Tag, cacheValue)
	default: // 其他功能码保持[]uint16
		cacheValue = data
		// log.Printf("[Device:%s] 保持Register数据: tag=%s, 数据=%v", d.Cfg.Name, t.Tag, cacheValue)
	}

	// 更新缓存
	if err := cache.Global.SetTag(t.Tag, cacheValue); err != nil {
		log.Printf("[Device:%s] 写cache失败 tag=%s: %v", d.Cfg.Name, t.Tag, err)
	} else {
		// log.Printf("[Device:%s] 写cache成功 tag=%s: value=%v", d.Cfg.Name, t.Tag, cacheValue)
	}

	d.markSuccess()
}

// ---------- 执行写任务 ----------
func (d *Device) runWriteTasks() {
	if d.Client == nil {
		return
	}

	for {
		select {
		case t := <-d.WriteQueue:
			val := cache.Global.GetTag(t.Tag)
			err := d.Client.Write(t.FC, t.Addr, val)
			if err != nil {
				d.markFail(err)
			} else {
				d.markSuccess()
			}
		default:
			return
		}
	}
}

// ---------- 在线状态处理 ----------
func (d *Device) markFail(err error) {
	d.RetryCount++
	log.Printf("[Device:%s] 通信失败(%d/%d): %v",
		d.Cfg.Name, d.RetryCount, config.C.Global.RetryTimes, err)

	if d.RetryCount >= config.C.Global.RetryTimes {
		d.Online = false
	}
}

func (d *Device) markSuccess() {
	d.RetryCount = 0
	d.Online = true
}

// ---------- 公共 ModbusClient 接口 ----------
type ModbusClient interface {
	Read(fc uint8, addr uint16, qty uint16) ([]uint16, error)
	Write(fc uint8, addr uint16, value interface{}) error
	Close() error
}

// 根据 RTU / TCP 创建客户端
func NewClient(cfg types.DeviceConfig) (ModbusClient, error) {
	if cfg.Type == "rtu" {
		return poller.NewRTUClient(cfg)
	}
	return poller.NewTCPClient(cfg)
}

// 设备状态信息（用于模板渲染）
type DeviceStatusInfo struct {
	Name        string
	Type        string
	Conn        string
	SlaveIDs    []uint8
	Online      bool
	SlaveStatus map[uint8]bool
}

// GetAllStatuses 返回所有设备的详细状态信息
func GetAllStatuses() []DeviceStatusInfo {
	var status []DeviceStatusInfo

	for _, d := range Devices {
		var conn string
		var slaveIDs []uint8
		var slaveStatus map[uint8]bool

		if d.Cfg.Type == "rtu" {
			conn = d.Cfg.Port
			slaveIDs = []uint8{d.Cfg.SlaveID}
			slaveStatus = map[uint8]bool{d.Cfg.SlaveID: d.Online}
		} else {
			conn = d.Cfg.Address
			slaveIDs = nil
			slaveStatus = nil
		}

		status = append(status, DeviceStatusInfo{
			Name:        d.Cfg.Name,
			Type:        d.Cfg.Type,
			Conn:        conn,
			SlaveIDs:    slaveIDs,
			Online:      d.Online,
			SlaveStatus: slaveStatus,
		})
	}

	return status
}
