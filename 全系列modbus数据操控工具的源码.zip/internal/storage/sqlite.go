package storage

import (
	"database/sql"
	"fmt"
	"log"
	"time"

	_ "github.com/mattn/go-sqlite3"

	"DB-HUB-ALL-modbus/internal/cache"
)

var db *sql.DB

// ===============================
// 初始化
// ===============================
func Init(path string) {
	var err error
	db, err = sql.Open("sqlite3", path)
	if err != nil {
		log.Fatal("open sqlite error: ", err)
	}

	createTable := `
	CREATE TABLE IF NOT EXISTS tag_log (
		id INTEGER PRIMARY KEY AUTOINCREMENT,
		ts TEXT,
		tag TEXT,
		value TEXT
	);
	`
	_, err = db.Exec(createTable)
	if err != nil {
		log.Fatal("create table error: ", err)
	}
}

// ===============================
// 保存差异化 tag（每轮 poll 调用一次）
// ===============================
func SaveDiff() {
	ts := time.Now().Format("2006-01-02 15:04:05")

	tx, err := db.Begin()
	if err != nil {
		log.Println("sqlite begin tx err:", err)
		return
	}

	stmt, err := tx.Prepare("INSERT INTO tag_log (ts, tag, value) VALUES (?,?,?)")
	if err != nil {
		log.Println("sqlite prepare err:", err)
		return
	}
	defer stmt.Close()

	// 统计保存的记录数
	savedCount := 0

	// ========== flag ==========
	for i := 0; i < 10000; i++ {
		if cache.Global.FlagChanged(i) {
			tag := fmt.Sprintf("flag_%04d", i)
			val := cache.Global.GetFlag(i)
			_, _ = stmt.Exec(ts, tag, fmt.Sprintf("%v", val))
			savedCount++
			// log.Printf("保存Flag变化: tag=%s, value=%v", tag, val)
		}
	}

	// ========== register ==========
	for i := 0; i < 10000; i++ {
		if cache.Global.RegisterChanged(i) {
			tag := fmt.Sprintf("register_%04d", i)
			val := cache.Global.GetRegister(i)
			_, _ = stmt.Exec(ts, tag, fmt.Sprintf("%d", val))
			savedCount++
			// log.Printf("保存Register变化: tag=%s, value=%v", tag, val)
		}
	}

	_ = tx.Commit()

	if savedCount > 0 {
		// log.Printf("数据库保存成功，共保存了 %d 条数据", savedCount)
	} else {
		// log.Println("没有变化的数据需要保存到数据库")
	}
}
