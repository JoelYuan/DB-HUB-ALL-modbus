package types

import "time"

type GlobalConfig struct {
	PollIntervalMs int    `yaml:"poll_interval_ms"`
	RetryTimes     int    `yaml:"retry_times"`
	DBPath         string `yaml:"db_path"`
	WebPort        int    `yaml:"web_port"`
}

type DeviceConfig struct {
	Name string `yaml:"name"`
	Type string `yaml:"type"` // rtu / tcp

	// RTU fields
	Port    string `yaml:"port"`
	Baud    int    `yaml:"baud"`
	SlaveID uint8  `yaml:"slave"`

	// TCP fields
	Address string `yaml:"address"`
	UnitID  uint8  `yaml:"unit"`

	ReadTasks  []ReadTaskConfig  `yaml:"read"`
	WriteTasks []WriteTaskConfig `yaml:"write"`
}

// ---------- 读任务 ----------
type ReadTaskConfig struct {
	FC       uint8  `yaml:"fc"`
	Addr     uint16 `yaml:"addr"`
	Tag      string `yaml:"tag"`
	PeriodMs int    `yaml:"period_ms"`
}

// ---------- 写任务 ----------
type WriteTaskConfig struct {
	FC   uint8  `yaml:"fc"`
	Addr uint16 `yaml:"addr"`
	Tag  string `yaml:"tag"`
}

// ---------- 运行时任务结构（用于调度器） ----------
type ReadTask struct {
	FC       uint8
	Addr     uint16
	Len      uint16
	Tag      string
	Period   time.Duration
	LastTime time.Time
}

type WriteTask struct {
	FC   uint8
	Addr uint16
	Tag  string
}
