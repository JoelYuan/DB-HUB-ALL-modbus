package mapping

import (
	"fmt"
	"strconv"

	"DB-HUB-ALL-modbus/internal/config"
)

// ============================================
// 任务池：每设备自己的读任务、写任务
// ============================================

type DeviceTaskPool struct {
	ReadTasks  []ParsedReadTask
	WriteTasks []ParsedWriteTask
}

// ----------------------------
// 解析后的读任务
// ----------------------------
type ParsedReadTask struct {
	ModbusType string // coil / discrete_input / holding_register / input_register
	Addr       uint16
	TargetID   int    // flag/register 序号
	TargetType string // "flag" or "reg"
}

// ----------------------------
// 解析后的写任务
// ----------------------------
type ParsedWriteTask struct {
	ModbusType string
	Addr       uint16
	SourceID   int
	SourceType string // "flag" or "reg"
}

// ============================================
// 对外接口：返回 map[设备名]*DeviceTaskPool
// ============================================
func BuildTaskPools(cfg *config.Config) (map[string]*DeviceTaskPool, error) {

	pools := make(map[string]*DeviceTaskPool)

	// ========== 初始化每个设备的任务池 ==========
	for _, dev := range cfg.Devices {
		pool := &DeviceTaskPool{
			ReadTasks:  make([]ParsedReadTask, 0),
			WriteTasks: make([]ParsedWriteTask, 0),
		}

		// ========== 解析读任务 ==========
		for _, t := range dev.ReadTasks {
			// 根据功能码判断Modbus类型
			modbusType, targetType := getModbusAndTargetType(t.FC)

			// 解析Tag名获取目标ID
			targetID, err := parseTagID(t.Tag)
			if err != nil {
				return nil, fmt.Errorf("read task target err: %v", err)
			}

			pool.ReadTasks = append(pool.ReadTasks, ParsedReadTask{
				ModbusType: modbusType,
				Addr:       t.Addr,
				TargetID:   targetID,
				TargetType: targetType,
			})
		}

		// ========== 解析写任务 ==========
		for _, t := range dev.WriteTasks {
			// 根据功能码判断Modbus类型
			modbusType, sourceType := getModbusAndTargetType(t.FC)

			// 解析Tag名获取源ID
			sourceID, err := parseTagID(t.Tag)
			if err != nil {
				return nil, fmt.Errorf("write task source err: %v", err)
			}

			pool.WriteTasks = append(pool.WriteTasks, ParsedWriteTask{
				ModbusType: modbusType,
				Addr:       t.Addr,
				SourceID:   sourceID,
				SourceType: sourceType,
			})
		}

		pools[dev.Name] = pool
	}

	return pools, nil
}

// ============================================
// 辅助：解析 tag 名到 (类型, ID)
// flag_0001 → ("flag",1)
// register_0123 → ("reg",123)
// ============================================
func parseTagName(s string) (string, int, error) {

	// --- flag_XXXX ---
	if len(s) == 9 && s[:5] == "flag_" {
		id, err := strconv.Atoi(s[5:])
		if err != nil || id < 0 || id >= 10000 {
			return "", 0, fmt.Errorf("invalid flag name: %s", s)
		}
		return "flag", id, nil
	}

	// --- register_XXXX ---
	if len(s) == 14 && s[:9] == "register_" {
		id, err := strconv.Atoi(s[9:])
		if err != nil || id < 0 || id >= 10000 {
			return "", 0, fmt.Errorf("invalid register name: %s", s)
		}
		return "reg", id, nil
	}

	return "", 0, fmt.Errorf("invalid tag name: %s", s)
}

// ============================================
// 辅助：根据功能码获取Modbus类型和目标类型
// ============================================
func getModbusAndTargetType(fc uint8) (string, string) {
	switch fc {
	case 1: // Read Coils
		return "coil", "flag"
	case 2: // Read Discrete Inputs
		return "discrete_input", "flag"
	case 3: // Read Holding Registers
		return "holding_register", "reg"
	case 4: // Read Input Registers
		return "input_register", "reg"
	case 5: // Write Single Coil
		return "coil", "flag"
	case 6: // Write Single Register
		return "holding_register", "reg"
	case 15: // Write Multiple Coils
		return "coil", "flag"
	case 16: // Write Multiple Registers
		return "holding_register", "reg"
	default:
		return "unknown", "unknown"
	}
}

// ============================================
// 辅助：解析 tag ID
// flag_0001 → 1
// register_0123 → 123
// ============================================
func parseTagID(s string) (int, error) {
	// --- flag_XXXX ---
	if len(s) >= 6 && s[:5] == "flag_" {
		id, err := strconv.Atoi(s[5:])
		if err != nil || id < 0 || id >= 10000 {
			return 0, fmt.Errorf("invalid flag name: %s", s)
		}
		return id, nil
	}

	// --- register_XXXX ---
	if len(s) >= 10 && s[:9] == "register_" {
		id, err := strconv.Atoi(s[9:])
		if err != nil || id < 0 || id >= 10000 {
			return 0, fmt.Errorf("invalid register name: %s", s)
		}
		return id, nil
	}

	return 0, fmt.Errorf("invalid tag name: %s", s)
}
