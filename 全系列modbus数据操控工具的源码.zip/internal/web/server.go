package web

import (
	"html/template"
	"log"
	"net/http"
	"strconv"

	"DB-HUB-ALL-modbus/internal/cache"
	"DB-HUB-ALL-modbus/internal/devices"
)

var tpl *template.Template

func Start(port int) {
	tpl = template.Must(template.ParseFiles("internal/web/templates/index.html"))

	http.HandleFunc("/", handleIndex)
	http.HandleFunc("/tag", handleTag)

	addr := ":" + strconv.Itoa(port)
	log.Println("Web server running at", addr)
	log.Fatal(http.ListenAndServe(addr, nil))
}

// ===========================
// 首页：设备状态
// ===========================
func handleIndex(w http.ResponseWriter, r *http.Request) {
	status := devices.GetAllStatuses() // Online/Offline

	data := map[string]interface{}{
		"Devices": status,
	}

	err := tpl.Execute(w, data)
	if err != nil {
		http.Error(w, err.Error(), 500)
	}
}

// ===========================
// tag 查询接口
// /tag?name=flag_0001
// ===========================
func handleTag(w http.ResponseWriter, r *http.Request) {
	name := r.URL.Query().Get("name")
	if name == "" {
		http.Error(w, "missing tag name", 400)
		return
	}

	// flag_xxxx
	if len(name) == 9 && name[:5] == "flag_" {
		id, err := strconv.Atoi(name[5:])
		if err == nil && id >= 0 && id < 10000 {
			v := cache.Global.GetFlag(id)
			w.Write([]byte(strconv.FormatBool(v)))
			return
		}
	}

	// register_xxxx
	if len(name) == 13 && name[:9] == "register_" {
		id, err := strconv.Atoi(name[9:])
		if err == nil && id >= 0 && id < 10000 {
			v := cache.Global.GetRegister(id)
			w.Write([]byte(strconv.Itoa(int(v))))
			return
		}
	}

	http.Error(w, "invalid tag", 400)
}
