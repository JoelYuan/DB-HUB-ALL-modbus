package cache

import (
	"fmt"
	"strconv"
	"sync"
)

// ==========================
// 全局缓存结构（tag 缓存区）
// ==========================
type Cache struct {
	mu sync.RWMutex

	Flags     [10000]bool
	Registers [10000]uint16

	PrevFlags     [10000]bool
	PrevRegisters [10000]uint16
}

// 单例
var Global = &Cache{}

// ==========================
// 快照：每轮 poll 开始时调用
// ==========================
func (c *Cache) Snapshot() {
	c.mu.RLock()
	defer c.mu.RUnlock()
	copy(c.PrevFlags[:], c.Flags[:])
	copy(c.PrevRegisters[:], c.Registers[:])
}

// ==========================
// Flag 操作（线程安全）
// ==========================
func (c *Cache) SetFlag(id int, v bool) {
	if id < 0 || id >= 10000 {
		return
	}
	c.mu.Lock()
	c.Flags[id] = v
	c.mu.Unlock()
}

func (c *Cache) GetFlag(id int) bool {
	if id < 0 || id >= 10000 {
		return false
	}
	c.mu.RLock()
	defer c.mu.RUnlock()
	return c.Flags[id]
}

// ==========================
// Register 操作（线程安全）
// ==========================
func (c *Cache) SetRegister(id int, v uint16) {
	if id < 0 || id >= 10000 {
		return
	}
	c.mu.Lock()
	c.Registers[id] = v
	c.mu.Unlock()
}

func (c *Cache) GetRegister(id int) uint16 {
	if id < 0 || id >= 10000 {
		return 0
	}
	c.mu.RLock()
	defer c.mu.RUnlock()
	return c.Registers[id]
}

// ==========================
// Tag 操作（线程安全）
// ==========================
func (c *Cache) SetTag(tag string, value interface{}) error {
	// Parse tag name to get type and ID
	tagType, id, err := parseTag(tag)
	if err != nil {
		return err
	}

	c.mu.Lock()
	defer c.mu.Unlock()

	switch tagType {
	case "flag":
		if v, ok := value.(bool); ok {
			c.Flags[id] = v
		} else {
			return fmt.Errorf("invalid value type for flag tag %s: expected bool, got %T", tag, value)
		}
	case "reg":
		if v, ok := value.(uint16); ok {
			c.Registers[id] = v
		} else if v, ok := value.([]uint16); ok && len(v) > 0 {
			// Handle slice for multiple registers (store first value)
			c.Registers[id] = v[0]
		} else {
			return fmt.Errorf("invalid value type for register tag %s: expected uint16 or []uint16, got %T", tag, value)
		}
	default:
		return fmt.Errorf("invalid tag type: %s", tagType)
	}

	return nil
}

func (c *Cache) GetTag(tag string) interface{} {
	// Parse tag name to get type and ID
	tagType, id, err := parseTag(tag)
	if err != nil {
		return nil
	}

	c.mu.RLock()
	defer c.mu.RUnlock()

	switch tagType {
	case "flag":
		return c.Flags[id]
	case "reg":
		return c.Registers[id]
	default:
		return nil
	}
}

// ==========================
// Helper: Parse tag name
// ==========================
func parseTag(s string) (string, int, error) {
	// --- flag_XXXX ---
	if len(s) >= 6 && s[:5] == "flag_" {
		id, err := strconv.Atoi(s[5:])
		if err != nil || id < 0 || id >= 10000 {
			return "", 0, fmt.Errorf("invalid flag tag: %s", s)
		}
		return "flag", id, nil
	}

	// --- register_XXXX ---
	if len(s) >= 10 && s[:9] == "register_" {
		id, err := strconv.Atoi(s[9:])
		if err != nil || id < 0 || id >= 10000 {
			return "", 0, fmt.Errorf("invalid register tag: %s", s)
		}
		return "reg", id, nil
	}

	return "", 0, fmt.Errorf("invalid tag format: %s", s)
}

// ==========================
// Diff 变化（供 sqlite 落库）
// 判断本次与上周期是否不同
// ==========================
func (c *Cache) FlagChanged(id int) bool {
	if id < 0 || id >= 10000 {
		return false
	}
	c.mu.RLock()
	defer c.mu.RUnlock()
	return c.Flags[id] != c.PrevFlags[id]
}

func (c *Cache) RegisterChanged(id int) bool {
	if id < 0 || id >= 10000 {
		return false
	}
	c.mu.RLock()
	defer c.mu.RUnlock()
	return c.Registers[id] != c.PrevRegisters[id]
}
